/**
 * Created by Moses on 2017/8/4..
 */
const config = {
  showConfig: false,
  env: 'pro',
};

module.exports = config;
