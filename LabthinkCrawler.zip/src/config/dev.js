/**
 * Created by Moses on 2017/8/4.
 */
const config = {
  showConfig: true,
  env: 'dev',
};

module.exports = config;
