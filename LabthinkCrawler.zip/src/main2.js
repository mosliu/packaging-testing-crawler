const config = require('./config');

console.dir(config.crawler.confArray);
