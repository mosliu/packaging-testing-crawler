const WEBSITEFLAG = {
  MOCON: 'mocon.com',
  SUMSPRING: 'sumspring.com',
  GBTEST: 'gbtest.cn',
  SYSTESTER: 'systester.com',
  LABSTONE: 'labstone.cn',
  DRICK: 'drick.cn',
  CSCII: 'cscii.com',
};
Object.freeze(WEBSITEFLAG);
module.exports = WEBSITEFLAG;

