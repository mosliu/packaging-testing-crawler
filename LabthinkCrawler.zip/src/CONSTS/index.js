const INFOTYPE = require('./INFOTYPE');
const WEBSITEFLAG = require('./WEBSITEFLAG');

const OBJ = {
  INFOTYPE, WEBSITEFLAG,
};
Object.freeze(OBJ);
module.exports = OBJ;
